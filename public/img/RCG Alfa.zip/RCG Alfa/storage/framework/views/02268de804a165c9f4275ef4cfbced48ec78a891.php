<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <h2 class="texto-oferta">Ofertas</h2> 
    <br>
    
    <div class="row">
         <div class="col-10">
              <form class="d-flex" method="GET" action="<?php echo e(route('consultar_ofertas')); ?>">
                <?php echo csrf_field(); ?>
                <input class="form-control me-3 texto_m" name="consulta_of" value="<?php echo e(Session::get('criterio_of')); ?>" type="search" placeholder="Digite palavras para consulta..." aria-label="Consultar">
                <button class="btn btn btn-primary me-3 texto_m" type="submit">Procurar</button>
              </form>
         </div>
         <div class="col">
              <form action="mostra_varios_parts" method="post">
                    <?php echo csrf_field(); ?>

                    <?php if(isset($ofps_map)): ?> 
                    <button class="btn btn-mapa btn-sm bi-globe texto_m" type="submit"> Mapa Geral</button>

                        <input value="0" name="nome_part" type="hidden">
                        <input value="Oferta" name="of_nec" type="hidden">
                        <input value="<?php echo e(Session::get('latitude')); ?>" name="latitude" type="hidden">
                        <input value="<?php echo e(Session::get('longitude')); ?>" name="longitude" type="hidden">

                        <?php if(count($ofps_map)>0): ?>
                            <?php $__currentLoopData = $ofps_map; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ofp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                                <input value="<?php echo e($ofp->id_part); ?>" name="parts[<?php echo e($loop->index); ?>][id]" type="hidden">
                                <input value="<?php echo e($ofp->latitude); ?>" name="parts[<?php echo e($loop->index); ?>][latitude]" type="hidden">
                                <input value="<?php echo e($ofp->longitude); ?>" name="parts[<?php echo e($loop->index); ?>][longitude]" type="hidden">
                                <input value="<?php echo e($ofp->nome_part); ?>" name="parts[<?php echo e($loop->index); ?>][nome_part]" type="hidden">
                                <input value="<?php echo e($ofp->endereco); ?>" name="parts[<?php echo e($loop->index); ?>][endereco]" type="hidden">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                    <?php endif; ?>


              </form>

        </div>

    </div>
    <br>
    <?php if(isset($ofps)): ?> 

    <table class="table table-sm">
        <thead class="texto_m">
          <tr>
            <th scope="col" >Imagem</th>
            <th scope="col" >Descrição</th>
            <th scope="col">Data</th>
            <th scope="col">Quant</th>
            <th scope="col">Unidade</th>
            <th scope="col" colspan="2">Transações</th>
            <!-- <th scope="col" >Status Of</th>-->
            <th scope="col">Status</th>
            <th scope="col" >Local</th>
 
          </tr>
        </thead>
        <tbody>
          <?php if(count($ofps)>0): ?>
              
              <?php $__currentLoopData = $ofps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ofp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                  <td>
                    <div class="col-1" >
                              <figure class="figure">
                  
                                <?php if(!@empty($ofp->imagem)): ?>
                                    <img id="imagem_of_cons"  src="/uploads/of_img/<?php echo e($ofp->imagem); ?>" class="imagem-of-nec-cons">
                                <?php else: ?>
                                    <img id="imagem_of_cons" src="/img/logo.jpg" class="imagem-of-nec-cons">
                                <?php endif; ?> 
                        
                            </figure>
                      </div>
                  </td>
                  <td>
                    <div style="width: 45rem;">

                      <div>
                          <div class="row align-items-start">
                               <div class="col">
                                    <h5 style="font-size:15px;"   class="card-title texto-oferta">Oferta : <?php echo e($ofp->desc_of); ?></h5>
                                    <h6 style="color:rgb(4, 97, 97)"  class="card-subtitle mb-2 texto_m">Categoria : <?php echo e($ofp->desc_cat); ?> </h6>
                                    <p class="card-text texto_m">Obs : <?php echo e($ofp->obs); ?></p>
                               </div>
                               <div class="col">
                                    <h6 class="texto_m">Nome : <?php echo e($ofp->nome_part); ?> </h6>
                                    <p class="texto_m">Endereço : <?php echo e($ofp->endereco); ?> , <?php echo e($ofp->cidade); ?> <?php echo e($ofp->estado); ?> - <?php echo e($ofp->pais); ?></p>
                               </div>
                        
                          </div>
                      </div>
                    </div>
                  </td>

                  <td class="texto_m">
                    <?php
                        $date = new DateTime($ofp->data);
                        echo $date->format('d-m-Y');
                     ?>
                  </td>
                  <td class="texto_m"><?php echo e($ofp->quant); ?></td>
                  <td class="texto_m"><?php echo e($ofp->desc_unid); ?></td>
                    
                    <td>
                      <div class="row">
                          
                            <div class="col">
                                  <?php if($ofp->id_part <> Session::get('id_logado')): ?>
                                    <form action="<?php echo e(route('trans_trocas_part')); ?>" method="get">
                                      <?php echo csrf_field(); ?> 
                                      <input value="<?php echo e($ofp->id_part); ?>" name="id_part_t" type="hidden">
                                      <input value="<?php echo e($ofp->id_of_part); ?>" name="id_of_part_t" type="hidden">
                                      <input value="0" name="filtra_id_logado" type="hidden">
                                      <input value="<?php echo e(Session::get('id_logado')); ?>" name="id_logado" type="hidden">

                                      <p><button type="submit" class="btn btn-sm btn-trocar bi-arrow-repeat texto_p">&nbspTrocar</button></p>   
                                    </form>
                                  <?php else: ?>
                                    <form action="<?php echo e(route('trans_ofertas_part')); ?>" method="get">
                                      <?php echo csrf_field(); ?> 
                                      <button type="submit" class="btn btn-sm btn-sugestoes bi-arrow-down-up texto_p">
                                        Sugestões <span class="badge sugestao-of-nec">
                                                  <?php echo e(App\Http\Controllers\OfertasController::verifica_sugestoes_of(Session::get('id_logado'),$ofp->desc_cat,$ofp->desc_of,$ofp->obs,1)); ?>

                                                  </span>
                                      </button>
                                      <input value="1" name="filtra_id_logado" type="hidden">
                                      <input value="<?php echo e($ofp->id_part); ?>" name="id_part_t" type="hidden">
                                      <input value="<?php echo e($ofp->id_of_part); ?>" name="id_of_part_t" type="hidden">
                                      
                                    </form>
                                  <?php endif; ?>  
                            </div>
                         
                      </div>  
                    </td>    
                    <td></td>

                  <!--  <?php if($ofp->status == 2): ?>
                        <td class="texto_p texto-em-andamento"><h4 class="bi bi-chat-left-dots-fill"></h4></td>
                    <?php else: ?>
                        <?php if(($ofp->status == 3)): ?>
                            <td class="texto_p texto-parc-finalizada"><h4 class="bi bi-check-circle-fill"></h4></td>
                        <?php else: ?> 
                            <?php if($ofp->status == 4): ?>
                                <td class="texto_p texto-finalizada"><h4 class="bi bi-check-circle-fill"></h4></td>
                            <?php else: ?>  
                                <td class="texto_p"></td>
                            <?php endif; ?>
                        <?php endif; ?>  
                    <?php endif; ?>    -->

                    <td>
                      <div class="row">
                        <div class="col-1 texto-em-andamento">
                          <span>
                          <?php
                             echo App\Http\Controllers\IniciaController::consulta_status_transacoes_of_anda($ofp->id_of_part)
                          ?>  
                        </span>
                        </div>

                        <div class="col-2 texto-em-andamento">
                          <h6 class="bi bi-chat-left-dots-fill"></h6>
                        </div>

                        <div class="col-1 texto-parc-finalizada">
                          <span >
                          <?php
                             echo App\Http\Controllers\IniciaController::consulta_status_transacoes_of_parc($ofp->id_of_part)
                          ?>  
                        </span>
                        </div>

                        <div class="col-2 texto-parc-finalizada">
                          <h6 class="bi bi-check-circle-fill"></h6>
                        </div>

                        <div class="col-1 texto-finalizada">
                          <span >
                          <?php
                             echo App\Http\Controllers\IniciaController::consulta_status_transacoes_of_final($ofp->id_of_part)
                          ?>  
                        </span>
                        </div>

                        <div class="col-1 texto-finalizada">
                          <h6 class="bi bi-check-circle-fill"></h6>
                        </div>

                      </div>
                    </td>

                    <td>
                          <div style="" class="col">
                          <?php if($ofp->latitude<>null): ?>
                            <form  action="/mostramapa/<?php echo e($ofp->id_part); ?>" method="post">
                                  <?php echo csrf_field(); ?>
                                  <button type="submit" class="btn btn-mapa btn-sm bi-globe texto_p">
                                    Mapa
                                    </button>
                              </form>
                          <?php else: ?>
                              <form action="/mostramapa/<?php echo e($ofp->id_part); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-mapa-disable btn-sm bi-globe texto_p">
                                  Mapa
                                </button>
                              </form>
                          <?php endif; ?>
                          </div>

                    </td>
                    
                  </tr>
                </div> 
                
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <?php else: ?>
          <tr>
            <td>Nenhum registro encontrado</td>    
            <td></td>  
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
          </tr>    
          <?php endif; ?> 

        </tbody>
      </table>

      <div class="pagination">
           <?php echo e($ofps->links('layouts.paginationlinks')); ?>

           
      </div>

    <?php endif; ?> 
 
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Gui\Desktop\work\RCG\resources\views/ofertas.blade.php ENDPATH**/ ?>