<?php $__env->startSection('content'); ?>

<div class="container">

    <h3 class="texto-moeda">Saldos das Moedas do Participante</h3> 
    <h5 class="texto-participante"><?php echo e(Session('nomelogado')); ?></h5> 
    <br>

    <?php if(isset($saldos)): ?> 

    <table class="table table-sm texto_m">
        <thead>
          <tr>
            <th scope="col">Moeda</th>
            <th scope="col">Saldo</th>
          </tr>
        </thead>
        <tbody>
          <?php if(count($saldos)>0): ?>
              <?php $__currentLoopData = $saldos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                  <tr>
                    <td><?php echo e($sd->desc_moeda); ?></td>
                    <td>
                      <?php
                         echo number_format($sd->tot_moeda,2,",",".");
                      ?>
                      
                    </td>
                  </tr>
                </div> 
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <?php else: ?>
              <td><td>Nenhum registro encontrado</td></td>    
          <?php endif; ?> 

        </tbody>
      </table>

      <div class="pagination">
           <?php echo e($saldos->links('layouts.paginationlinks')); ?>

           
      </div>

    <?php endif; ?> 
  </div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\RCG Alfa\resources\views/moedas_part.blade.php ENDPATH**/ ?>