<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <h2 class="texto-necessidade">Necessidades</h2> 
    <br>
    
    <div class="row">
         <div class="col-10">
              <form class="d-flex" method="GET" action="<?php echo e(route('consultar_necessidades')); ?>">
                <?php echo csrf_field(); ?>
                <input class="form-control me-3 texto_m" name="consulta_nec" value="<?php echo e(Session::get('criterio_nec')); ?>" type="search" placeholder="Digite palavras para consulta..." aria-label="Consultar">
                <button class="btn btn btn-primary me-3 texto_m" type="submit">Procurar</button>
              </form>
         </div>
         <div class="col">
              <form action="mostra_varios_parts" method="post">
                    <?php echo csrf_field(); ?>

                    <?php if(isset($necps_map)): ?> 
                    <button class="btn btn-mapa btn-sm bi-globe texto_m" type="submit"> Mapa Geral</button>

                        <input value="0" name="nome_part" type="hidden">
                        <input value="Necessidade" name="of_nec" type="hidden">
                        <input value="<?php echo e(Session::get('latitude')); ?>" name="latitude" type="hidden">
                        <input value="<?php echo e(Session::get('longitude')); ?>" name="longitude" type="hidden">

                        <?php if(count($necps_map)>0): ?>
                            <?php $__currentLoopData = $necps_map; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $necp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                                <input value="<?php echo e($necp->id_part); ?>" name="parts[<?php echo e($loop->index); ?>][id]" type="hidden">
                                <input value="<?php echo e($necp->latitude); ?>" name="parts[<?php echo e($loop->index); ?>][latitude]" type="hidden">
                                <input value="<?php echo e($necp->longitude); ?>" name="parts[<?php echo e($loop->index); ?>][longitude]" type="hidden">
                                <input value="<?php echo e($necp->nome_part); ?>" name="parts[<?php echo e($loop->index); ?>][nome_part]" type="hidden">
                                <input value="<?php echo e($necp->endereco); ?>" name="parts[<?php echo e($loop->index); ?>][endereco]" type="hidden">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                    <?php endif; ?>


              </form>

        </div>

    </div>
    <br>
    <?php if(isset($necps)): ?> 

    <table class="table table-sm">
        <thead class="texto_m">
          <tr>
            <th scope="col">Imagem</th>
            <th scope="col">Descrição</th>
            <th scope="col">Data</th>
            <th scope="col">Quant</th>
            <th scope="col">Unidade</th>
            <th scope="col" colspan="2">Transações</th>
            <th scope="col" >Status</th>
            <th scope="col" >Local</th>
 
          </tr>
        </thead>
        <tbody>
          <?php if(count($necps)>0): ?>
              
              <?php $__currentLoopData = $necps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $necp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                  <td>
                    <div class="col-1" >
                              <figure class="figure">
                  
                                <div class="d-block d-lg-none d-md-none d-xl-none d-xxl-none">
                                    <?php if(!@empty($necp->imagem)): ?>
                                        <img id="imagem_nec_cons"  src="/uploads/nec_img/<?php echo e($necp->imagem); ?>" class="imagem-of-nec-cons-p">
                                    <?php else: ?>
                                        <img id="imagem_nec_cons" src="/img/logo.jpg" class="imagem-of-nec-cons-p">
                                    <?php endif; ?> 
                                </div>

                                <div class="d-none d-sm-none d-md-block d-lg-block d-xl-block d-xxl-block">
                                     <?php if(!@empty($necp->imagem)): ?>
                                        <img id="imagem_nec_cons"  src="/uploads/nec_img/<?php echo e($necp->imagem); ?>" class="imagem-of-nec-cons">
                                     <?php else: ?>
                                        <img id="imagem_nec_cons" src="/img/logo.jpg" class="imagem-of-nec-cons">
                                     <?php endif; ?> 
                                </div>
                        
                            </figure>
                      </div>
                  </td>
                  <td>
                    <div style="width: auto;">

                      <div>
                            <div class="row align-items-start">
                               <div class="col">
                                    <h5 style="font-size:15px;"   class="card-title texto-necessidade">Necessidade : <?php echo e($necp->desc_nec); ?></h5>
                                    <h6 style="color:rgb(97, 75, 4)"  class="card-subtitle mb-2 texto_m">Categoria : <?php echo e($necp->desc_cat); ?> </h6>
                                    <p class="card-text texto_m">Obs : <?php echo e($necp->obs); ?></p>
                               </div>

                               <div class="d-lg-none">
                                <p></p><h6 class="texto_m">Nome : <?php echo e($necp->nome_part); ?> </h6></p>
                                <p class="texto_p">Endereço : <?php echo e($necp->endereco); ?> , <?php echo e($necp->cidade); ?> <?php echo e($necp->estado); ?> - <?php echo e($necp->pais); ?></p>
                               </div>

                               <div class="col d-none d-sm-none d-sx-none d-md-none d-lg-block">
                                    <h6 class="texto_m">Nome : <?php echo e($necp->nome_part); ?> </h6>
                                    <p class="texto_m">Endereço : <?php echo e($necp->endereco); ?> , <?php echo e($necp->cidade); ?> <?php echo e($necp->estado); ?> - <?php echo e($necp->pais); ?></p>
                               </div>
                        
                            </div>

                      </div>
                    </div>
                  </td>

                  <td>
                      <div class="texto_m d-none d-sm-none d-md-none d-lg-block d-xl-block d-xxl-block">
                          <?php $date = new DateTime($necp->data); echo $date->format('d-m-Y'); ?>
                      </div>
                      <div class="texto_p d-xs-block d-sm-block d-md-block d-lg-none d-xl-none d-xxl-none">
                          <?php $date = new DateTime($necp->data); echo $date->format('d-m-Y'); ?>
                      </div>
                  </td>
                  <td class="texto_m"><?php echo e($necp->quant); ?></td>
                  <td class="texto_m"><?php echo e($necp->desc_unid); ?></td>
                    
                    <td>
                      <div class="row">
                            <div class="col">
                                <form action="<?php echo e(route('trans_necessidades_part')); ?>" method="get">
                                  <?php echo csrf_field(); ?> 

                                  <?php if($necp->id_part <> Session::get('id_logado')): ?>
                                      <button type="submit" class="btn btn-sm btn-sugestoes-of bi-arrow-down-up texto_p">
                                        Sugestões <span class="badge sugestao-of-nec">
                                                  <?php echo e(App\Http\Controllers\NecessidadesController::verifica_sugestoes_nec(Session::get('id_logado'),$necp->desc_cat,$necp->desc_nec,$necp->obs,0)); ?>

                                                  </span>
                                      </button>

                                      <input value="0" name="filtra_id_logado" type="hidden">
                                  <?php else: ?>
                                      <button type="submit" class="btn btn-sm btn-sugestoes bi-arrow-down-up texto_p">
                                        Sugestões <span class="badge sugestao-of-nec">
                                                  <?php echo e(App\Http\Controllers\NecessidadesController::verifica_sugestoes_nec(Session::get('id_logado'),$necp->desc_cat,$necp->desc_nec,$necp->obs,1)); ?>

                                                  </span>
                                      </button>

                                      <input value="1" name="filtra_id_logado" type="hidden">
                                  <?php endif; ?>

                                  <input value="<?php echo e($necp->id_part); ?>" name="id_part_t" type="hidden">
                                  <input value="<?php echo e($necp->id_nec_part); ?>" name="id_nec_part_t" type="hidden">
                                  <input value="<?php echo e(Session::get('id_logado')); ?>" name="id_logado" type="hidden">

                                </form>
                            </div>
                         
                      </div>  
                    </td>    
                    <td></td>
                    
                   

                    <td>
                      <div class="row">
                        <div class="col-1 texto-em-andamento">
                          <span >
                          <?php
                             echo App\Http\Controllers\IniciaController::consulta_status_transacoes_nec_anda($necp->id_nec_part)
                          ?>  
                        </span>
                        </div>

                        <div class="col-2 texto-em-andamento d-none d-sm-none d-md-none d-lg-block d-xl-block d-xxl-block">
                          <h6 class="bi bi-chat-left-dots-fill"></h6>
                        </div>

                        <div class="col-1 texto-parc-finalizada">
                          <span >
                          <?php
                             echo App\Http\Controllers\IniciaController::consulta_status_transacoes_nec_parc($necp->id_nec_part)
                          ?>  
                        </span>
                        </div>

                        <div class="col-2 texto-parc-finalizada d-none d-sm-none d-md-none d-lg-block d-xl-block d-xxl-block">
                          <h6 class="bi bi-check-circle-fill"></h6>
                        </div>

                        <div class="col-1 texto-finalizada">
                          <span >
                          <?php
                             echo App\Http\Controllers\IniciaController::consulta_status_transacoes_nec_final($necp->id_nec_part)
                          ?>  
                        </span>
                        </div>

                        <div class="col-3 texto-finalizada d-none d-sm-none d-md-none d-lg-block d-xl-block d-xxl-block">
                          <h6 class="bi bi-check-circle-fill"></h6>
                        </div>

                      </div>
                    </td>
                    
                    <td>
                          <div style="" class="col">
                          <?php if($necp->latitude<>null): ?>
                            <form  action="/mostramapa/<?php echo e($necp->id_part); ?>" method="post">
                                  <?php echo csrf_field(); ?>
                                  <button type="submit" class="btn btn-mapa btn-sm bi-globe texto_p">
                                    Mapa
                                    </button>
                              </form>
                          <?php else: ?>
                              <form action="/mostramapa/<?php echo e($necp->id_part); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-mapa-disable btn-sm bi-globe texto_p">
                                  Mapa
                                </button>
                              </form>
                          <?php endif; ?>
                          </div>

                    </td>
                    
                  </tr>
                </div> 
                
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <?php else: ?>
          <tr>
            <td>Nenhum registro encontrado</td>    
            <td></td>  
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
          </tr>    
          <?php endif; ?> 

        </tbody>
      </table>

      <div class="pagination">
           <?php echo e($necps->links('layouts.paginationlinks')); ?>

           
      </div>

    <?php endif; ?> 
 
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\RCG Alfa\resources\views/necessidades.blade.php ENDPATH**/ ?>