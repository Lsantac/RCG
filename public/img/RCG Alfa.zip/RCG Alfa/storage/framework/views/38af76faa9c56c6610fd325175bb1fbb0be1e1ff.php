
  <div class="card text-center">
    
    <div class="card-body">
      <h5 class="card-title">Rede Colaborativa Global</h5>
      <p class="card-text">Prosperidade para todos os cantos do Planeta.</p>
      
    </div>
    
  </div>

<?php /**PATH D:\Laravel\RCG Alfa\resources\views/footer.blade.php ENDPATH**/ ?>