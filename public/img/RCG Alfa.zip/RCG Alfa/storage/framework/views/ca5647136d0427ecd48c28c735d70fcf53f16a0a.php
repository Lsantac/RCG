<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <h2 class="texto-necessidade">Necessidades do Participante</h2>
    <h5 class="texto-participante"><?php echo e($part->nome_part); ?></h5>
    <br>

    <div class='results'>
      <?php if(Session::get('success')): ?>
          <div class="alert alert-success">
              <?php echo e(Session::get('success')); ?>

          </div>
      <?php endif; ?>

      <?php if(Session::get('fail')): ?>
          <div class="alert alert-danger">
              <?php echo e(Session::get('fail')); ?>

          </div>
      <?php endif; ?>

    </div>

    <form class="row g-3" method="GET" action="<?php echo e(route('consultar_necessidades_part')); ?>">

          <?php echo csrf_field(); ?>

          <div class="col-sm-7">
               <input class="form-control texto_p" name="consulta_nec_part" value="<?php echo e(Session::get('criterio_nec_part')); ?>" placeholder="Digite palavras para consulta..." type="search">
               <input name="id_part" type="hidden" value="<?php echo e($part->id); ?>">
          </div>

        <div class="col-sm">
          <button style="margin-right: 20px" class="btn btn-sm btn-primary " type="submit">Procurar</button>
          <!--<a class="btn btn btn-redes bi-snow" type="button"> Incluir Rede</a> -->

          <!-- Button trigger modal -->
          <?php if(Session::get('id_logado') == $part->id): ?>
            <button type="button" class="btn btn-incluir-necessidades btn-sm bi-arrow-up-circle-fill" data-bs-toggle="modal" data-bs-target="#Incluirnecessidade">
              Incluir Necessidade
            </button>
            <button type="button" class="btn btn-criar-necessidades btn-sm bi-arrow-up-circle-fill" data-bs-toggle="modal" data-bs-target="#Novanecessidade">
              Criar novo tipo de Necessidade
            </button>
          <?php endif; ?>
        </div>

    </form>

    <form action="<?php echo e(route('incluir_necessidades_part')); ?>" method="post" enctype="multipart/form-data">

      <?php echo csrf_field(); ?>

          <!-- Modal Incluir necessidade-->
          <div class="modal fade" id="Incluirnecessidade" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="staticBackdropLabel">Incluir Necessidade de : <?php echo e($part->nome_part); ?></h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                      <div class="modal-body">

                        <div class="row">
                          <!-- <div class="col-2">
                                <figure class="figure">
                                      <img id="imagem_nec" src="/img/logo.jpg" class="figure-img img-fluid imagem-of-nec img-thumbnail ">
                                </figure>
                          </div> -->

                          <div class="col-12" style="align-self: flex-end;">
                             <label for="sel_img" class="form-label texto_m">Selecionar imagem</label>
                             <input id="sel_img" accept="image/*" data-msg-placeholder="Selecione uma imagem"
                                name="sel_img" type="file" class="file" data-browse-on-zone-click="true"
                                >
                              <!-- <input  name="sel_img" id="sel_img" type="file" accept=".jpg,.png,.jpeg" onchange ="mostra_imagem(this, 'inclusao',0)" class="form-control form-control-sm <?php $__errorArgs = ['sel_img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" > -->
                              <label class="form-label red-message"><?php echo e(Session::get('fail image')); ?></label>
                          </div>

                        </div>

                        <div class="mb-3">

                          <input value="<?php echo e($part->id); ?>" name="id_part" type="hidden">

                          <label for="exampleFormControlInput1" class="form-label">Selecione um tipo de necessidade</label>
                          <select type="text" name="id_nec" id="exampleFormControlInput1" class="form-select" aria-label="Default select example" required>
                            <option value = ""></option>
                            <?php $__currentLoopData = $necs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($nec->id); ?>">
                                    <?php echo e($nec->descricao); ?>

                              </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                          <br>

                          <label for="data_nec" class="form-label">Data</label>
                          <input type="date" class="form-control" id="data_nec" name="data_nec" required>
                          <br>

                          <label for="quant_nec" class="form-label">Quantidade</label>
                          <input type="number" step="0.010" class="form-control" id="quant_nec" name="quant_nec" required>

                          <br>

                          <label for="obs_nec" class="form-label">Observações</label>
                          <textarea type="text" class="form-control" id="obs_nec" name="obs_nec"></textarea>
                        </div>

                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-sair" data-bs-dismiss="modal">Sair</button>
                      <button type="submit" class="btn btn-primary">Incluir</button>
                    </div>
              </div>
            </div>
          </div>
    </form>

    <form action="<?php echo e(route('nova_necessidade')); ?>" method="post">

      <?php echo csrf_field(); ?>

    <!-- Modal Criar Nova necessidade -->
    <div class="modal fade" id="Novanecessidade" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
      <div class="modal-dialog modal-xl">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="staticBackdropLabel">Criar novo tipo de Necessidade</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>

          <div class="modal-body">
               <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Descrição</label>
                <input type="text" class="form-control" id="exampleFormControlInput1" name="descricao" required>
              </div>
              <div class="mb-3">
                <label for="categoria" class="form-label">Selecione uma Categoria</label>
                <select type="text" name="categoria" id="categoria" class="form-select" aria-label="Default select example" required>
                  <option value = ""></option>
                  <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cat->id); ?>">
                          <?php echo e($cat->descricao); ?>

                    </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <br>
                <label for="unidade" class="form-label">Selecione uma Unidade</label>
                <select type="text" name="unidade" id="unidade" class="form-select" aria-label="Default select example" required>
                  <option value = ""></option>
                  <?php $__currentLoopData = $unids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($unid->id); ?>">
                          <?php echo e($unid->descricao); ?>

                    </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>

          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-sair" data-bs-dismiss="modal">Sair</button>
            <button type="submit" class="btn btn-primary">Salvar</button>
          </div>
        </div>
      </div>
    </div>

    </form>

    <br>

    <?php if(isset($necps)): ?>

    <table class="table table-sm">
        <thead style="border-bottom: 1px solid black;">
          <tr>
            <th scope="col" class="texto_p">Imagem</th>
            <th scope="col" class="texto_p">Descrição</th>
            <th scope="col" class="texto_p">Data</th>
            <th scope="col" class="texto_p">Quant</th>
            <th scope="col" class="texto_p">Unidade</th>
            <th scope="col" class="texto_p" style="text-align:left;">Transações</th>
            <th scope="col" class="texto_p" >Status</th>

            <?php if(Session::get('id_logado') == $part->id): ?>
                <th scope="col" class="texto_p" >Ações</th>
            <?php endif; ?>
          </tr>
        </thead>

        <tbody>
          <?php if(count($necps)>0): ?>

              <?php $__currentLoopData = $necps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $necp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                  <tr>
                    <td>
                        <figure class="figure">

                          <div class="d-block d-lg-none d-md-none d-xl-none d-xxl-none">
                            <?php if(!@empty($necp->imagem)): ?>
                                <img id="imagem_nec_cons"  src="/uploads/nec_img/<?php echo e($necp->imagem); ?>" class="imagem-of-nec-cons-p">
                            <?php else: ?>
                                <img id="imagem_nec_cons" src="/img/logo.jpg" class="imagem-of-nec-cons-p">
                            <?php endif; ?> 
                          </div>

                          <div class="d-none d-sm-none d-md-block d-lg-block d-xl-block d-xxl-block">
                              <?php if(!@empty($necp->imagem)): ?>
                                  <img id="imagem_nec_cons"  src="/uploads/nec_img/<?php echo e($necp->imagem); ?>" class="imagem-of-nec-cons">
                              <?php else: ?>
                                  <img id="imagem_nec_cons" src="/img/logo.jpg" class="imagem-of-nec-cons">
                              <?php endif; ?> 
                          </div>

                      </figure>
            
                    </td>

                    <td>
                        <div class="col" style="width:auto;">
                          <h5 style="font-size:15px;"  class="card-title texto-necessidade">Necessidade : <?php echo e($necp->desc_nec); ?></h5>
                          <h6 style="color:rgb(97, 75, 4)" class="card-subtitle mb-2 texto_m">Categoria : <?php echo e($necp->desc_cat); ?> </h6>
                          <p class="card-text texto_m">Obs : <?php echo e($necp->obs); ?></p>
                        </div>
                    </td>

                    <td class="texto_p">
                      <?php if($necp->data): ?>
                        <?php
                          $date = new DateTime($necp->data);
                          echo $date->format('d-m-Y');
                        ?>
                      <?php endif; ?>
                    </td>
                    <td class="texto_p"><?php echo e($necp->quant); ?></td>
                    <td class="texto_p"><?php echo e($necp->desc_unid); ?></td>

                   <!-- <?php if($necp->status == 2): ?>
                        <td class="texto_p texto-em-andamento"><h4 class="bi bi-chat-left-dots-fill"></h4></td>
                    <?php else: ?>
                        <?php if(($necp->status == 3)): ?>
                            <td class="texto_p texto-parc-finalizada"><h4 class="bi bi-check-circle-fill"></h4></td>
                        <?php else: ?>
                            <?php if($necp->status == 4): ?>
                                <td class="texto_p texto-finalizada"><h4 class="bi bi-check-circle-fill"></h4></td>
                            <?php else: ?>
                                <td class="texto_p"></td>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?> -->

                    <td>
                      <?php if(Session::get('id_logado') == $part->id): ?>
                        <form action="<?php echo e(route('trans_necessidades_part')); ?>" method="get">
                              <?php echo csrf_field(); ?>
                              <button type="submit" class="btn btn-sm btn-sugestoes bi-arrow-down-up texto_p">
                                Sugestões <span class="badge sugestao-of-nec">
                                          <?php echo e(App\Http\Controllers\NecessidadesController::verifica_sugestoes_nec(Session::get('id_logado'),$necp->desc_cat,$necp->desc_nec,$necp->obs,1)); ?>

                                          </span>
                              </button>
                              <input value="true" name="filtra_id_logado" type="hidden">
                              <input value="<?php echo e($part->id); ?>" name="id_part_t" type="hidden">
                              <input value="<?php echo e($necp->id_nec_part); ?>" name="id_nec_part_t" type="hidden">
                        </form>
                      <?php else: ?>
                          <form action="<?php echo e(route('trans_necessidades_part')); ?>" method="get">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-sm btn-sugestoes bi-arrow-down-up texto_p">
                              Sugestões <span class="badge sugestao-of-nec">
                                        <?php echo e(App\Http\Controllers\NecessidadesController::verifica_sugestoes_nec(Session::get('id_logado'),$necp->desc_cat,$necp->desc_nec,$necp->obs,0)); ?>

                                        </span>
                            </button>
                            <input value="0" name="filtra_id_logado" type="hidden">
                            <input value="<?php echo e($part->id); ?>" name="id_part_t" type="hidden">
                            <input value="<?php echo e($necp->id_nec_part); ?>" name="id_nec_part_t" type="hidden">
                          </form>
                      <?php endif; ?>
                    </td>

                    <td>
                      <div class="row">
                        <div class="col-1 texto-em-andamento">
                          <span >
                          <?php
                             echo App\Http\Controllers\IniciaController::consulta_status_transacoes_nec_anda($necp->id_nec_part)
                          ?>
                        </span>
                        </div>

                        <div class="col-2 texto-em-andamento d-none d-sm-none d-md-none d-lg-block d-xl-block d-xxl-block">
                          <h6 class="bi bi-chat-left-dots-fill"></h6>
                        </div>

                        <div class="col-1 texto-parc-finalizada">
                          <span >
                          <?php
                             echo App\Http\Controllers\IniciaController::consulta_status_transacoes_nec_parc($necp->id_nec_part)
                          ?>
                        </span>
                        </div>

                        <div class="col-2 texto-parc-finalizada d-none d-sm-none d-md-none d-lg-block d-xl-block d-xxl-block">
                          <h6 class="bi bi-check-circle-fill"></h6>
                        </div>

                        <div class="col-1 texto-finalizada">
                          <span >
                          <?php
                             echo App\Http\Controllers\IniciaController::consulta_status_transacoes_nec_final($necp->id_nec_part)
                          ?>
                        </span>
                        </div>

                        <div class="col-1 texto-finalizada d-none d-sm-none d-md-none d-lg-block d-xl-block d-xxl-block">
                          <h6 class="bi bi-check-circle-fill"></h6>
                        </div>

                      </div>
                    </td>

                    <td>
                        <div class="row">

                          <div class="col">

                            <?php if(Session::get('id_logado') == $part->id): ?>
                              <button class="btn btn-editar btn-sm bi bi-pencil texto_p" type="submit" data-bs-toggle="modal" data-bs-target="#Editarnecessidade-<?php echo e($necp->id_nec_part); ?>"> Editar</button>
                            <?php endif; ?>

                            <form action="<?php echo e(route('altera_necessidade_part')); ?>" method="post" enctype="multipart/form-data">
                              <?php echo csrf_field(); ?>
                                <!-- Modal Alterar necessidade-->
                                <div class="modal fade" id="Editarnecessidade-<?php echo e($necp->id_nec_part); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                  <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                      <div class="modal-header">
                                        <h5 class="modal-title" id="staticBackdropLabel">Alterar Necessidade de : <?php echo e($part->nome_part); ?></h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                      </div>
                                            <div class="modal-body">

                                              <div class="row">
                                                <div class="col-2">
                                                      <figure class="figure">

                                                        <?php if(!@empty($necp->imagem)): ?>
                                                            <img id="imagem_nec_alt-<?php echo e($necp->id_nec_part); ?>"  src="/uploads/nec_img/<?php echo e($necp->imagem); ?>" class="imagem-of-nec">
                                                        <?php else: ?>
                                                            <img id="imagem_nec_alt-<?php echo e($necp->id_nec_part); ?>" src="/img/logo.jpg" class="figure-img img-fluid imagem-of-nec img-thumbnail ">
                                                        <?php endif; ?>

                                                    </figure>

                                                </div>

                                                <div class="col-10" style="align-self: flex-end;">
                                                  <label for="sel_img_alt" class="form-label texto_m">Selecionar imagem</label>
                                                    <input  name="sel_img_alt" id="sel_img_alt" type="file" accept=".jpg,.png,.jpeg" onchange ="mostra_imagem(this,'editar',<?php echo e($necp->id_nec_part); ?>)" class="form-control form-control-sm <?php $__errorArgs = ['sel_img_alt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                                                    <label class="form-label red-message"><?php echo e(Session::get('fail image')); ?></label>
                                                </div>

                                              </div>

                                              <div class="mb-3">
                                                <input value="<?php echo e($part->id); ?>" name="id_part" type="hidden">
                                                <input value="<?php echo e($necp->id_nec_part); ?>" name="id_nec_part" type="hidden">

                                                <label for="FormControl_id_nec" class="form-label">Selecione um tipo de Necessidade</label>
                                                <select type="text" name="id_nec" id="FormControl_id_nec" class="form-select" aria-label="Default select example" required>
                                                  <option value="<?php echo e($necp->id_nec); ?>" selected><?php echo e($necp->desc_nec); ?></option>
                                                  <?php $__currentLoopData = $necs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($nec->id); ?>">
                                                          <?php echo e($nec->descricao); ?>

                                                    </option>
                                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <br>

                                                <label for="data_nec" class="form-label">Data</label>
                                                <input type="date" value="<?php echo e($necp->data); ?>"  class="form-control" id="data_nec" name="data_nec" required>
                                                <br>

                                                <label for="quant_nec" class="form-label">Quantidade</label>
                                                <input type="number" step="0.010" value="<?php echo e($necp->quant); ?>" class="form-control" id="quant_nec" name="quant_nec" required>

                                                <br>

                                                <label for="obs_nec" class="form-label">Observações</label>
                                                <textarea type="text" class="form-control" id="obs_nec" name="obs_nec" value=""><?php echo e($necp->obs); ?></textarea>
                                              </div>

                                          </div>
                                          <div class="modal-footer">
                                            <button type="button" class="btn btn-sair" data-bs-dismiss="modal">Sair</button>
                                            <button type="submit" class="btn btn-primary">Alterar</button>
                                          </div>
                                    </div>
                                  </div>
                                </div>
                              </form>

                        </div>
                        
                        <div class="col">

                            <?php if(Session::get('id_logado') == $part->id): ?>
                                <button class="btn btn-danger btn-sm bi bi-trash texto_p" type="button" data-bs-toggle="modal" data-bs-target="#ModalExcluinecessidade-<?php echo e($necp->id_nec_part); ?>" >Excluir</button>
                            <?php endif; ?>

                            <form class="" action="/deleta_necessidade_part/<?php echo e($necp->id_nec_part); ?>" method="POST">
                                  <?php echo csrf_field(); ?>
                                  <?php echo method_field('DELETE'); ?>

                                  <!-- Modal -->
                                  <div class="modal fade" id="ModalExcluinecessidade-<?php echo e($necp->id_nec_part); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                      <div class="modal-content">
                                        <div class="modal-header">
                                          <h5 class="modal-title" id="exampleModalLabel">Confirma Exclusão da necessidade "<?php echo e($necp->desc_nec); ?>" para <?php echo e($part->nome_part); ?> ?</h5>
                                          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>

                                        <div class="modal-footer">
                                          <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Sair</button>
                                          <button type="submit" class="btn btn-danger">Excluir</button>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                            </form>

                        </div>
                        
                      </div>  

                    </td>

                  </tr>
                </div>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <?php else: ?>
              <td>Nenhum registro encontrado</td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
          <?php endif; ?>

        </tbody>
      </table>

      <div class="pagination">
           <?php echo e($necps->links('layouts.paginationlinks')); ?>


      </div>

    <?php endif; ?>

<div>

  <script>

    function mostra_imagem(input,$modo,$id_nec_part){

             if (input.files && input.files[0]) {

               var reader = new FileReader();

               reader.onload = function (e) {
                     if($modo == 'inclusao'){
                       $('#imagem_nec').attr('src', e.target.result);
                     }else{
                       if($modo == 'editar'){
                          $('#imagem_nec_alt-' + $id_nec_part).attr('src', e.target.result);

                       }
                     }

               };
               reader.readAsDataURL(input.files[0]);

             }

    }

 </script>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\RCG Alfa\resources\views/consultar_necessidades_part.blade.php ENDPATH**/ ?>