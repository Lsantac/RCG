<?php $__env->startSection('content'); ?>


<div class="container-fluid">
    <?php if($status == 2): ?>
        <h4 class="texto-oferta" style="color:rgb(197, 15, 233);">Transações em andamento para as Ofertas do Participante</h4> 
    <?php else: ?>
        <?php if($status == 3): ?>
            <h4 class="texto-oferta" style="color:rgb(15, 135, 233);">Transações de Ofertas com confirmação parcial do Participante</h4> 
        <?php else: ?>
            <?php if($status == 4): ?>
                <h4 class="texto-oferta" style="color:rgb(101, 12, 218);">Transações Finalizadas para as Ofertas do Participante</h4> 
            <?php endif; ?>    
        <?php endif; ?>
    <?php endif; ?>
     
    
    <h4 class="texto-nome-logado"><?php echo e(Session::get('nomelogado')); ?></h4> 
    <br>

    <form class="row g-3" method="get" action="/cons_trans_ofertas_part/<?php echo e($status); ?>/<?php echo e(Session::get('id_logado')); ?>">

          <?php echo csrf_field(); ?>
     
          <div class="col-sm-8">
               <input class="form-control texto_m" name="cons_of_tela_inic" value="<?php echo e(Session::get('criterio_of_tela_inic')); ?>" placeholder="Digite palavras para consulta..." type="search">
          </div>
      
        <div class="col-sm">
          <button style="margin-right: 20px" class="btn btn-sm btn-primary " type="submit">Procurar</button>
          
        </div>
        
    </form>

    <br>

    <?php if(isset($of_status)): ?> 

    <table  class="table table-sm">
        <thead style="border-bottom: 1px solid black;" class="texto_m">
          <tr>

             <th scope="col">Ofertas</th>
             <th scope="col">Necessidades/Trocas</th>
             <th scope="col">Definições</th>
             <th scope="col">Ações</th>
            
          </tr>
        </thead>

        <tbody>
          <?php if(count($of_status)>0): ?>

              <?php $__currentLoopData = $of_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $of_st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                       <tr>
                        
                        <td>
                           
                            <div class="card" >
                              
                                  <div class="card-body" style="background-color:rgb(199, 245, 207) ">
                                        <div class="row">
                                            <div style="width:auto;">
                                                  <figure class="figure">

                                                    <div class="d-block d-lg-none d-md-none d-xl-none d-xxl-none">
                                                      <?php if(!@empty($of_st->imagem_of)): ?>
                                                         <img id="imagem_of_cons"  src="/uploads/of_img/<?php echo e($of_st->imagem_of); ?>" class="imagem-of-nec-cons-p">
                                                      <?php else: ?>
                                                         <img id="imagem_of_cons" src="/img/logo.jpg" class="imagem-of-nec-cons-p">
                                                      <?php endif; ?> 
                                                    </div>
                          
                                                    <div class="d-none d-sm-none d-md-block d-lg-block d-xl-block d-xxl-block">
                                                         <?php if(!@empty($of_st->imagem_of)): ?>
                                                            <img id="imagem_of_cons"  src="/uploads/of_img/<?php echo e($of_st->imagem_of); ?>" class="imagem-of-nec-cons">
                                                         <?php else: ?>
                                                            <img id="imagem_of_cons" src="/img/logo.jpg" class="imagem-of-nec-cons">
                                                         <?php endif; ?> 
                                                    </div>
                                                  
                                                  </figure>
                                            </div>

                                            <div class="col">
                                                  <div class="row align-items-start">
                                                
                                                    <div class="col">
                                                      <div class="row">
                                                            <div class="col">
                                                                <h6 class="texto-oferta">Oferta : <?php echo e($of_st->desc_of); ?></h6>       
                                                            </div>
                                                            <div class="col texto_p">
                                                              <?php
                                                                  if($of_st->data_final_of_part <> null){
                                                                    $date = new DateTime($of_st->data_final_of_part);
                                                                    echo "Confirmada em : ".$date->format('d-m-Y'). " (UTC: ".$date->format('H:i').")" ;
                                                                  }
                                                              ?>

                                                            </div>
                                                          </div>
                                                      </div>

                                                      <div class="card-text texto_p">Categoria : <?php echo e($of_st->desc_cat_of); ?> </div>
                                                      <div class="texto_p">
                                                      <?php
                                                          if($of_st->data_inic <> null){
                                                            $date = new DateTime($of_st->data_inic);
                                                            echo "Início : ".$date->format('d-m-Y'). " (UTC: ".$date->format('H:i').")" ;
                                                          }
                                                      ?>
                                                      </div>

                                                      <div class="card-text texto_p">Participante : <?php echo e($of_st->nome_part_of); ?> </div>
                                                      <div class="card-text texto_p">Obs : <?php echo e($of_st->obs_of); ?></div>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                        
                                  </div>
                            </div>
                            
                        </td>
                        <td>
                          
                                  <div class="card" >
                                    <?php if($of_st->fluxo == 'Troca'): ?>
                                        <div class="card-body" style="background-color:rgb(172, 240, 223) ">
                                    <?php else: ?>
                                        <div class="card-body" style="background-color:rgb(245, 217, 199) ">
                                    <?php endif; ?>   

                                    <div class="row">
                                         <div style="width:auto;">
                                              <figure class="figure">

                                                <?php if($of_st->fluxo == 'Troca'): ?>   

                                                      <div class="d-block d-lg-none d-md-none d-xl-none d-xxl-none">
                                                           <?php if(!@empty($of_st->imagem_of_tr)): ?>
                                                              <?php if($of_st->imagem_of_tr <> $of_st->imagem_of): ?>
                                                                 <img id="imagem_of_tr_cons"  src="/uploads/of_img/<?php echo e($of_st->imagem_of_tr); ?>" class="imagem-of-nec-cons-p">
                                                              <?php endif; ?>
                                                           <?php else: ?>
                                                              <img id="imagem_of_tr_cons" src="/img/logo.jpg" class="imagem-of-nec-cons-p">
                                                           <?php endif; ?> 
                                                      </div>
                            
                                                      <div class="d-none d-sm-none d-md-block d-lg-block d-xl-block d-xxl-block">
                                                            <?php if(!@empty($of_st->imagem_of_tr)): ?>
                                                                  <?php if($of_st->imagem_of_tr <> $of_st->imagem_of): ?>
                                                                    <img id="imagem_of_tr_cons"  src="/uploads/of_img/<?php echo e($of_st->imagem_of_tr); ?>" class="imagem-of-nec-cons">
                                                                  <?php endif; ?>
                                                            <?php else: ?>
                                                                  <img id="imagem_of_tr_cons" src="/img/logo.jpg" class="imagem-of-nec-cons">
                                                            <?php endif; ?> 
                                                      </div>

                                                <?php else: ?>

                                                      <div class="d-block d-lg-none d-md-none d-xl-none d-xxl-none">
                                                          <?php if(!@empty($of_st->imagem_nec)): ?>
                                                              <img id="imagem_nec_cons"  src="/uploads/nec_img/<?php echo e($of_st->imagem_nec); ?>" class="imagem-of-nec-cons-p">
                                                          <?php else: ?>
                                                              <img id="imagem_nec_cons" src="/img/logo.jpg" class="imagem-of-nec-cons-p">
                                                          <?php endif; ?> 
                                                      </div>
                            
                                                      <div class="d-none d-sm-none d-md-block d-lg-block d-xl-block d-xxl-block">
                                                          <?php if(!@empty($of_st->imagem_nec)): ?>
                                                              <img id="imagem_nec_cons"  src="/uploads/nec_img/<?php echo e($of_st->imagem_nec); ?>" class="imagem-of-nec-cons">
                                                          <?php else: ?>
                                                              <img id="imagem_nec_cons" src="/img/logo.jpg" class="imagem-of-nec-cons">
                                                          <?php endif; ?> 
                                                      </div>

                                                <?php endif; ?>
                                          
                                              </figure>
                                         </div>
                                         <div class="col">
                                              <div class="row align-items-start">
                                                <div class="col">
                                                      <?php if($of_st->fluxo == 'Troca'): ?>
                                                        <div class="row">
                                                              <div class="col">
                                                                  <?php if($of_st->id_of == $of_st->id_of_tr_part): ?>
                                                                     <h6 class="card-title texto-troca">Troca : <?php echo e($of_st->desc_of_trans); ?></h6>       
                                                                  <?php else: ?>
                                                                     <h6 class="card-title texto-troca">Troca : <?php echo e($of_st->desc_of_tr); ?></h6>       
                                                                  <?php endif; ?>
                                                              </div>
                                                              <div class="col texto_p">
                                                                <?php
                                                                    if($of_st->data_final_of_tr_part <> null){
                                                                      $date = new DateTime($of_st->data_final_of_tr_part);
                                                                      echo "Confirmada em : ".$date->format('d-m-Y'). " (UTC: ".$date->format('H:i').")" ;
                                                                    }
                                                                ?>

                                                              </div>

                                                            </div>
                                                          </div>

                                                        <?php if($of_st->id_of == $of_st->id_of_tr_part): ?>
                                                            <div class="card-text texto_p">Categoria : <?php echo e($of_st->desc_cat_of_trans); ?></div>
                                                            <div class="card-text texto_p">Participante : <?php echo e($of_st->nome_part_of_trans); ?> </div>
                                                            <div class="card-text texto_p">Endereço : <?php echo e($of_st->endereco_of_trans); ?> , <?php echo e($of_st->cidade_of_trans); ?> </div>
                                                            <div class="card-text texto_p">Obs : <?php echo e($of_st->obs_of_trans); ?></div>   

                                                        <?php else: ?>
                                                            <div class="card-text texto_p">Categoria : <?php echo e($of_st->desc_cat_of_tr); ?></div>
                                                            <div class="card-text texto_p">Participante : <?php echo e($of_st->nome_part_of_tr); ?> </div>
                                                            <div class="card-text texto_p">Endereço : <?php echo e($of_st->endereco_of_tr); ?> , <?php echo e($of_st->cidade_of_tr); ?> </div>
                                                            <div class="card-text texto_p">Obs : <?php echo e($of_st->obs_of_tr); ?></div>   
                                                        <?php endif; ?>
                                                      <?php else: ?>
                                                        <div class="row">
                                                            <div class="col">
                                                                <h6 class="card-title texto-necessidade">Necessidade : <?php echo e($of_st->desc_nec); ?></h6>       
                                                            </div>
                                                            <div class="col texto_p">
                                                              <?php
                                                                  if($of_st->data_final_nec_part <> null){
                                                                    $date = new DateTime($of_st->data_final_nec_part);
                                                                    echo "Confirmada em : ".$date->format('d-m-Y'). " (UTC: ".$date->format('H:i').")" ;
                                                                  }
                                                              ?>

                                                            </div>

                                                          </div>
                                                        </div>

                                                        <div class="card-text texto_p">Categoria : <?php echo e($of_st->desc_cat_nec); ?></div>
                                                        <div class="card-text texto_p">Participante : <?php echo e($of_st->nome_part_nec); ?> </div>
                                                        <div class="card-text texto_p">Endereço : <?php echo e($of_st->endereco_nec); ?> , <?php echo e($of_st->cidade_nec); ?> </div>
                                                        <div class="card-text texto_p">Obs : <?php echo e($of_st->obs_nec); ?></div>   
                                                      <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
          
                                        
                                    </div>
                                  </div>
                            </div>
                        </td>

                        <td>
                          <div class="col">
                                  <div class="card" style="width: 10rem;" >

                                    <div class="card-body header-trans">
          
                                        <div class="row align-items-start">
                                            <div class="col">
                                                  <h6 class="card-title">Fluxo : <?php echo e($of_st->fluxo); ?></h6>
                                                  <div class="card-text texto_p">Qt Fluxo : <?php echo e($of_st->quant_moeda); ?></div>
                                                  <div class="card-text texto_p">Qt Oferta : <?php echo e($of_st->quant_of); ?></div>
                                                  <?php if($of_st->fluxo == 'Troca'): ?>
                                                      <div class="card-text texto_p">Qt Troca : <?php echo e($of_st->quant_of_tr); ?></div>
                                                  <?php else: ?>
                                                      <div class="card-text texto_p">Qt Necessidade : <?php echo e($of_st->quant_nec); ?></div>
                                                  <?php endif; ?>
                                                  
                                            </div>
                                            
                                        </div>
          
                                    </div>
                                  </div>
                            </div>
                        </td>
                        <td>
                          <form action="<?php echo e(route('mens_transacoes_part')); ?>" method="get">
                        
                            <?php echo csrf_field(); ?> 
                            <input value="<?php echo e(Session::get('id_logado')); ?>" name="id_part_t" type="hidden">
                            <input value="<?php echo e($of_st->id_nec_part); ?>" name="id_nec_part_t" type="hidden">
                            <input value="<?php echo e($of_st->id_of_part); ?>" name="id_of_part_t" type="hidden"> 
                            <input value="<?php echo e($of_st->id_of_tr_part); ?>" name="id_of_tr_part_t" type="hidden"> 
                            <?php if($of_st->fluxo == 'Troca'): ?>
                               <input value="tr" name="origem" type="hidden"> 
                            <?php else: ?>
                               <input value="of" name="origem" type="hidden"> 
                            <?php endif; ?>   
                            <button type="submit" class="btn btn-sm btn-mensagem bi-arrow-repeat texto_p">Detalhes da Transação</button>   
                           
                      </form>
                           
                       </td>
                       </tr>
    
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <?php else: ?>
              <td><td>Nenhum registro encontrado</td></td>    
              
          <?php endif; ?> 

        </tbody>
      </table>

      <div class="pagination">
           <?php echo e($of_status->links('layouts.paginationlinks')); ?>

           
      </div>

    <?php endif; ?> 

<div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\RCG Alfa\resources\views/cons_trans_ofertas_part.blade.php ENDPATH**/ ?>