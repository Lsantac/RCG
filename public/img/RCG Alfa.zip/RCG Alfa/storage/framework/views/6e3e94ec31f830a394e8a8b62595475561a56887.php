<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <h4 class="texto-oferta" style="color:rgb(91, 19, 207);">Possiveis trocas para a oferta do Participante : 
      <span class="texto-nome-logado"><?php echo e($part->nome_part); ?></span>
    </h4> 
    

     <?php if(isset($ofps)): ?> 

    <table class="table table-sm tabela-oferta texto_p">
        <thead>
          <tr>
            <th scope="col" >Imagem</th>
            <th scope="col" >Descrição</th>
            <th scope="col" >Categoria</th>
            <th scope="col" >Data</th>
            <th scope="col" >Quant</th>
            <th scope="col" >Unidade</th>
            <th scope="col" >Observações</th>
            
          </tr>
        </thead>

        <tbody>
              <?php $__currentLoopData = $ofps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ofp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                  <tr>

                    <td>
                      <div class="col-1" >
                                <figure class="figure">
                    
                                  <?php if(!@empty($ofp->imagem)): ?>
                                      <img id="imagem_of_cons"  src="/uploads/of_img/<?php echo e($ofp->imagem); ?>" class="imagem-pequena">
                                  <?php else: ?>
                                      <img id="imagem_of_cons" src="/img/logo.jpg" class="imagem-pequena">
                                  <?php endif; ?> 
                          
                              </figure>
                        </div>
                    </td>

                    <td><?php echo e($ofp->desc_of); ?></td>
                    <td><?php echo e($ofp->desc_cat); ?></td>

                    <td>
                      <?php if($ofp->data): ?>
                          <?php
                              $date = new DateTime($ofp->data);
                              echo $date->format('d-m-Y');
                          ?>
                      <?php endif; ?> 
                    </td>

                    <td><?php echo e($ofp->quant); ?></td>
                    <td><?php echo e($ofp->desc_unid); ?></td>
                    <td><?php echo e($ofp->obs); ?></td>
                    
                  </tr>
                </div> 
                
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
      </table>

    <?php endif; ?> 
 
    <h4 class="texto-oferta">Ofertas de : <span class="texto-nome-logado"><?php echo e(Session::get('nomelogado')); ?></span></h4>
     
    <br>

    <div style="float: left; width: 70%; "> 
        <form class="row g-3" method="get" action="<?php echo e(route('consultar_trans_trocas_part')); ?>">

          <?php echo csrf_field(); ?>
          <input name="id_part_t" type="hidden" value="<?php echo e($part->id); ?>"> 
          <input value="<?php echo e($ofp->id_of_part); ?>" name="id_of_part_t" type="hidden">        
          <input value="0" name="filtra_id_logado" type="hidden">
          <input value="<?php echo e(Session::get('id_logado')); ?>" name="id_logado" type="hidden">
    
          <div class="col-sm-10 g-3">
              <input class="form-control texto_m" name="consultar_trans_troca_part" value="" placeholder="Digite palavras para procurar outras ofertas para trocar..." type="search">
          </div>
      
          <div style="text-align:center;width: 5%;"  class="col-sm-2">
            <button style="margin-right: 5px" class="btn btn-sm btn-primary " type="submit">Procurar</button>
            <!--<a class="btn btn btn-redes bi-snow" type="button"> Incluir Rede</a> -->
          
          </div>
        
        </form>
      </div>

  <!--<div style="float: left; width: auto;">
    <form style="display:inline;" action="" method="get">
      <?php echo csrf_field(); ?> 
      
      <button type="submit" class="btn btn-sm btn-mostrar-mensagens texto_p">Mostrar Mensagens</button>   
      <input value="<?php echo e($part->id); ?>" name="id_part_t" type="hidden">
      <input value="<?php echo e($ofp->id_of_part); ?>" name="id_of_part_t" type="hidden">
      
    </form>
  </div> -->

    <?php if(count($of_tr_ps)>0): ?>
        <div style="float:left; margin-left:20px;"  >
        <form style="display:inline;" action="mostra_varios_parts" method="post">
          <?php echo csrf_field(); ?> 
          
          <button type="submit" class="btn btn-sm btn-mapa bi-globe texto_p"> Mapa</button> 

          <input value="<?php echo e($part->nome_part); ?>" name="nome_part" type="hidden">
          <input value="Oferta" name="of_nec" type="hidden">
          <input value="<?php echo e($part->latitude); ?>" name="latitude" type="hidden">
          <input value="<?php echo e($part->longitude); ?>" name="longitude" type="hidden">
          
          <?php $__currentLoopData = $of_tr_ps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $of_tr_p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
          <input value="<?php echo e($of_tr_p->id_part); ?>" name="parts[<?php echo e($loop->index); ?>][id]" type="hidden">
          <input value="<?php echo e($of_tr_p->latitude); ?>" name="parts[<?php echo e($loop->index); ?>][latitude]" type="hidden">
          <input value="<?php echo e($of_tr_p->longitude); ?>" name="parts[<?php echo e($loop->index); ?>][longitude]" type="hidden">
          <input value="<?php echo e($of_tr_p->nome_part); ?>" name="parts[<?php echo e($loop->index); ?>][nome_part]" type="hidden">
          <input value="<?php echo e($of_tr_p->endereco); ?>" name="parts[<?php echo e($loop->index); ?>][endereco]" type="hidden">
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        </form>
        </div>  
   <?php else: ?>
   <div style="float:left; margin-left:20px;"  >
    
      <button type="submit" class="btn btn-sm btn-mapa-disable bi-globe texto_p"> Mapa</button> 
    
    </div>  
   <?php endif; ?>

  <br>
  <br>
  
     <?php if(isset($of_tr_ps)): ?> 

    <table class="table table-sm tabela-oferta">
        <thead>
          <tr>
            <th scope="col" class="texto_p">Imagem</th>
            <th scope="col" class="texto_p">Descrição</th>
            <th scope="col" class="texto_p">Data</th>
            <th scope="col" class="texto_p">Quant</th>
            <th scope="col" class="texto_p">Unidade</th>
            <th scope="col" class="texto_p">Status</th>
            <th class="texto_p " colspan="3">Ações</th>
          </tr>
        </thead>

        <tbody>
          <?php if(count($of_tr_ps)>0): ?>

              <?php $__currentLoopData = $of_tr_ps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $of_tr_p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                  <tr>
                    <td>
                      <div class="col-1" >
                                <figure class="figure">

                                  <div class="d-block d-lg-none d-md-none d-xl-none d-xxl-none">
                                    <?php if(!@empty($of_tr_p->imagem)): ?>
                                       <img id="imagem_of_tr_cons"  src="/uploads/of_img/<?php echo e($of_tr_p->imagem); ?>" class="imagem-of-nec-cons-p">
                                    <?php else: ?>
                                       <img id="imagem_of_tr_cons" src="/img/logo.jpg" class="imagem-of-nec-cons-p">
                                    <?php endif; ?>   
                                  </div>
                    
                                  <div class="d-none d-sm-none d-md-block d-lg-block d-xl-block d-xxl-block">
                                    <?php if(!@empty($of_tr_p->imagem)): ?>
                                       <img id="imagem_of_tr_cons"  src="/uploads/of_img/<?php echo e($of_tr_p->imagem); ?>" class="imagem-of-nec-cons">
                                    <?php else: ?>
                                       <img id="imagem_of_tr_cons" src="/img/logo.jpg" class="imagem-of-nec-cons">
                                    <?php endif; ?>   
                                  </div>
                                  
                          
                              </figure>
                        </div>
                    </td>

                      <td>
                      <div style="width: auto;">
                          <h5 class="card-title">Oferta : <?php echo e($of_tr_p->desc_of); ?></h5>
                          <h6 style="color:rgb(6, 155, 30)" class="card-subtitle mb-2 texto_p">Categoria : <?php echo e($of_tr_p->desc_cat); ?> </h6>
                          <p class="card-text texto_p">Obs : <?php echo e($of_tr_p->obs); ?></p>
                          <p style="color:rgb(4, 82, 155)" class="card-subtitle mb-1 texto_p">Participante : <?php echo e($of_tr_p->nome_part); ?></p>
                          <p style="color:rgb(4, 82, 155)" class="card-subtitle mb-1 texto_p">Endereço : <?php echo e($of_tr_p->endereco); ?> , <?php echo e($of_tr_p->cidade); ?> </p>
                      </div>
                      </td>

                    <td class="texto_p">
                      <?php
                          $date = new DateTime($of_tr_p->data);
                          echo $date->format('d-m-Y');
                       ?>
                    </td>
                    
                    <td class="texto_p"><?php echo e($of_tr_p->quant); ?></td>
                    <td class="texto_p"><?php echo e($of_tr_p->desc_unid); ?></td>

                  

                    <td>
                      <div class="row">
                        <div class="col-1 texto-em-andamento">
                          <span>
                          <?php
                            echo App\Http\Controllers\IniciaController::consulta_status_transacoes_of_anda($of_tr_p->id_of_part)
                          ?>  
                        </span>
                        </div>

                        <div class="col-2 texto-em-andamento d-none d-sm-none d-md-none d-lg-block d-xl-block d-xxl-block">
                          <h6 class="bi bi-chat-left-dots-fill"></h6>
                        </div>

                        <div class="col-1 texto-parc-finalizada">
                          <span >
                          <?php
                            echo App\Http\Controllers\IniciaController::consulta_status_transacoes_of_parc($of_tr_p->id_of_part)
                          ?>  
                        </span>
                        </div>

                        <div class="col-2 texto-parc-finalizada d-none d-sm-none d-md-none d-lg-block d-xl-block d-xxl-block">
                          <h6 class="bi bi-check-circle-fill"></h6>
                        </div>

                        <div class="col-1 texto-finalizada">
                          <span >
                          <?php
                            echo App\Http\Controllers\IniciaController::consulta_status_transacoes_of_final($of_tr_p->id_of_part)
                          ?>  
                        </span>
                        </div>

                        <div class="col-1 texto-finalizada d-none d-sm-none d-md-none d-lg-block d-xl-block d-xxl-block">
                          <h6 class="bi bi-check-circle-fill"></h6>
                        </div>

                      </div>
                    </td>
                    
                    <td>
                      <form action="<?php echo e(route('mens_transacoes_part')); ?>" method="get">
                        
                            <?php echo csrf_field(); ?> 
                            <input value="<?php echo e($part->id); ?>" name="id_part_t" type="hidden">
                            <input value="<?php echo e($of_tr_p->id_of_part); ?>" name="id_of_tr_part_t" type="hidden">
                            <input value="<?php echo e($ofp->id_of_part); ?>" name="id_of_part_t" type="hidden"> 
                            <input value="tr" name="origem" type="hidden"> 
                            <button type="submit" class="btn btn-sm btn-mensagem bi-arrow-repeat texto_p"> Detalhes da Transação</button>   
                           
                      </form>
                    </td>
                  </tr>
                </div> 
                
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <?php else: ?>
              <td>Nenhum registro encontrado</td>    
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>    
          <?php endif; ?> 

        </tbody>
      </table>

    <?php endif; ?> 

    <div class="pagination">
      <?php echo e($of_tr_ps->links('layouts.paginationlinks')); ?>

      
    </div>
<div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\RCG Alfa\resources\views/trans_trocas_part.blade.php ENDPATH**/ ?>