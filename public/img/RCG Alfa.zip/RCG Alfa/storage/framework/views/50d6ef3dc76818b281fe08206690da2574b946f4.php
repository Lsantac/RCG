<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <h2 class="texto-participante">Participantes</h2> 
    <br>
    <div class='results'>
        <?php if(Session::get('fail_mapa')): ?>
            <div class="alert alert-danger texto_p">
                <?php echo e(Session::get('fail_mapa')); ?>

            </div>
        <?php endif; ?>
    </div>
    
    <form  class="d-flex" method="GET" action="<?php echo e(route('procura')); ?>">

        <?php echo csrf_field(); ?>

        <input class="form-control me-2 texto_m" name="consulta" value="<?php echo e(Session::get('criterio_cons_part')); ?>" type="search" placeholder="Digite palavras para consulta..." aria-label="Consultar">
        
        <!--<select id="inputRede" name="rede" class="form-select me-2">
          <option selected>Procurar na Rede...</option>
          
        </select>-->
        
        <input class="form-control me-2 texto_m" list="rede-list" name="consulta_redes" value="<?php echo e(Session::get('criterio_cons_rede')); ?>" id="consulta_redes" type="search" placeholder="Consulta por Rede...">
        <datalist id="rede-list">
                  <?php $__currentLoopData = $redes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rede): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option value="<?php echo e($rede->nome); ?>"> 
                                  <?php echo e($rede->nome); ?> 
                           </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </datalist> 
        
        <button class="btn btn btn-primary me-2 texto_p" type="submit">Procurar</button>
            
    </form>

    <!--<form class="d-flex" action="" method="post">
      <?php echo csrf_field(); ?>
      <button type="submit" class="btn btn-mapa-geral btn-sm bi-globe no-margin">
        Mapa Geral
      </button>

    </form>-->
    

    <br>
    <?php if(isset($part)): ?> 

    <table class="table table-sm texto_p">
        <thead>
          <tr class="">
            <th scope="col">Foto</th>
            <th scope="col">Nome</th>
            <th scope="col">Endereço</th>
            <th scope="col">Cidade</th>
            <th scope="col">Estado</th>
            <th scope="col">Pais</th>
            <th scope="col">Cep</th>
            <th scope="col">Email</th>
            
            <?php if(Session::get('cons_rede')): ?>
               <th scope="col">Rede</th>
            <?php endif; ?>

            <th>Ações</th>
          </tr>
        </thead>
        <tbody>
          <?php if(count($part)>0): ?>

              <?php $__currentLoopData = $part; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                  <tr>
                    <!--<th scope="row"><?php echo e($p->id); ?></th>-->
                    <td>
                      
                      <?php if(!@empty($p->imagem)): ?>
                          <img src="/uploads/participantes/<?php echo e($p->imagem); ?>" class="imagem-header">
                      <?php else: ?>
                          <img src="/img/logo.jpg" class="imagem-header">
                      <?php endif; ?> 

                    </td>
                    
                    <td><?php echo e($p->nome_part); ?></td>
                    <td><?php echo e($p->endereco); ?></td>
                    <td><?php echo e($p->cidade); ?></td>
                    <td><?php echo e($p->estado); ?></td>
                    <td><?php echo e($p->pais); ?></td>
                    <td><?php echo e($p->cep); ?></td>
                    <td><?php echo e($p->email); ?></td>

                    <?php if(Session::get('cons_rede')): ?>
                       <td><?php echo e($p->nome_rede); ?>&nbsp&nbsp&nbsp&nbsp&nbsp</td>
                    <?php endif; ?>
                    
                    <td>
                      <div class="row">
                      <form class="col no-margin" action="/participantes/<?php echo e($p->id); ?>" method="POST">
                          <!--<a href="/alterar_participantes/<?php echo e($p->id); ?>" class="btn btn-warning btn-sm"><i class="bi bi-pencil">Alterar</i></a>
                          <?php echo csrf_field(); ?>
                          <?php echo method_field('DELETE'); ?>
                          <button class="btn btn-danger btn-sm bi bi-trash" type="submit">Excluir</button>  -->
                          
                          <a href="/consultar_participante/<?php echo e($p->id); ?>" class="btn btn-violeta btn-sm bi-card-text btn-detalhes texto_p"> Detalhes</a> 
                          
                       </form>   
                  
                       <form class="col" action="/mostramapa/<?php echo e($p->id); ?>" method="post">

                        <?php echo csrf_field(); ?>

                        <?php if($p->latitude<>null): ?>
                              <button type="submit" class="btn btn-mapa btn-sm bi-globe texto_p">
                        <?php else: ?>
                              <button type="submit" class="btn btn-mapa-disable btn-sm bi-globe texto_p">
                        <?php endif; ?>
                               Mapa
                              </button>

                        </form>

                      </div>
                    </td>
                    
                  </tr>
                </div> 
                
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <?php else: ?>
          <tr>
            <td>Nenhum registro encontrado</td>    
            <td></td>  
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
          </tr>    
          <?php endif; ?> 

        </tbody>
      </table>

      <div class="pagination">
           <?php echo e($part->links('layouts.paginationlinks')); ?>

           
      </div>

    <?php endif; ?> 

</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\RCG Alfa\resources\views/participantes.blade.php ENDPATH**/ ?>